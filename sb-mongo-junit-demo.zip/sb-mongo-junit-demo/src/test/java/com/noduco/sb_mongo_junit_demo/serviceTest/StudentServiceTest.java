package com.noduco.sb_mongo_junit_demo.serviceTest;


import com.noduco.sb_mongo_junit_demo.model.Student;
import com.noduco.sb_mongo_junit_demo.repo.StudentRepo;
import com.noduco.sb_mongo_junit_demo.service.StudentService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.core.classloader.annotations.PrepareForTest;

import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


@RunWith(PowerMockRunner.class)
@PrepareForTest(fullyQualifiedNames =  "com.noduco.sb_mongo_junit_demo.*")
public class StudentServiceTest {
    @InjectMocks
    private StudentService studentService;

    @Mock
    private StudentRepo studentRepo;
//    Student mockStudent ;
    Integer studentId = 1;

//    @BeforeEach
//    public void setUp() {
//
//        mockStudent = new Student(1,"Abc","B.Tech", "MMMUT");
//    }

    @Test
    public void getStudentByIdTest() {

        // Arrange
        Student  mockStudent = new Student(1,"Abc","B.Tech", "MMMUT");

        when(studentRepo.findById(studentId)).thenReturn(Optional.of(mockStudent));

        // Act
        Student result = studentService.getStudentById(studentId);


        // Assert
        assertNotNull(result);
        Assertions.assertEquals(studentId, result.getId());
        Assertions.assertEquals("Abc", result.getName());
        Assertions.assertEquals("B.tech", result.getCourse());
        verify(studentRepo, Mockito.times(1)).findById(studentId);

    }
}
