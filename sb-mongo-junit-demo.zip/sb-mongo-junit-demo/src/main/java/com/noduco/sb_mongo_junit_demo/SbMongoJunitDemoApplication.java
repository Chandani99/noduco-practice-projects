package com.noduco.sb_mongo_junit_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbMongoJunitDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbMongoJunitDemoApplication.class, args);
	}

}
